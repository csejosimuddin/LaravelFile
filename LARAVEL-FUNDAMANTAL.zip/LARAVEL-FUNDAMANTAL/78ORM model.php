class 78 Eloquent ORM মানে হছে model 
Model মানেই DataBase নিয়ে কাজ data insert,edite,delete আর ও যে যে কাজ হয় 
class 79
SQL এর সাথে বা টেবিল এ operation চালাতে হলে model নিয়ে কাজ করতে হয়
 Data Base এ যয়টা টেবিল থাকবে তইটা model তৈরি করতে হবে
 একটি টেবিল কে controll করার জনে একটি মডেল সহজ কথায়

 model তৈরির commend> php artisan make:model modelএর নাম
 নতুন তৈরি model থাকবে app ফোলডারের মধে

 class 80 Model Properties

 1. To define table name > protected $table = 'table name';
 2. To define primary column > protected $primaryKey = 'id';
 3. To define increaments status> public $incrementing = false; এখানে $primaryKey = 'id'; যদি autoincrement হয় তাহলে $incrementing = true;হবে নইলে false হবে
 4. To define primary column data type> protected $keyType = 'string';  মানে $primaryKey = 'id';টা যদি number হয় তাহলে int আর word হয় তাহরে string হবে
 5. To define date formate> protected $dateFormat='U';টেবিলে date থাকলে date এর ফরমেট বলে দিব
 6. To define db connection> protected $connection = 'connection-name'; যে টেবিল নিয়ে কাজ করছি ।ঔ টেবিল কোন ডাটাবেসের connection use করবে

 7. To define timesamps status> public $timestamps= false;যদি টেবিলে timestamps নামে কোন কলাম থাকে তাহলে true আর না থাকলে false হবে

 যে নতুন মডেল তৈরি করলাম সেখানে table টাকে connect করে দিই
 EXM:controller এর মধে
 {
 	protected $table ='students';
 	protected $primaryKey ='id';
 	public $incrementing =true;
 	protected $keyType ='int';
 	public $timestamps =false;
 }

 class 81 মডেল use এর বাসিক বিষয়:

 Query Builder ও Model Use এর মধে বাসিক পাথক
 DB::table('students') এর পরিবতে ModelClass:: হবে
 যেমন: DB::table('students')....expression;
 		ModelClass::....expressionহবে

Retrieving by Modelএটা Query Builder থেকে এসেছে 

1.Retrieving All Rows From A table >> ModelName::get();
2.Retrieving A Single Row >> ModelName::where('name','=','josim')->first();
3.Column From A Table >> ModelName::where('name','josim')->value('email');
যেখানে id=8 সেখানের name টা just চাছি
DB::table('user')->where('id','=','9')->value('name');

4. ow by its id column value,use the find method>> ModelName::find(3);
5. Retrieving A List of column value>> ModelName::pluck('title');
6. Retrieving A List Of Column Values>> ModelName::pluck('title','name');

Aggregates by Modelএটা Query Builder থেকে এসেছে 

1. Count Row Number >> ModelName::count();
2. Find Max value >> $price=ModelName::max('কলামের নাম যার max value বের করব যেমন id');
3. Find Min value >> $price=ModelName::min('কলামের নাম যার Min value বের করব যেমন id');
4. Find Average >> $price=ModelName::avg('কলামের নাম যার avg value বের করব যেমন roll');

select by Modelএটা Query Builder থেকে এসেছে 

1. ইউনিক ডাটা select করে দেখানোর জনে >> ModelName::distinct()->get();
2. select single column >> ModelName::select('name');
3. select multipul column >> ModelName::select('','')->get();

marge by Modelএটা Query Builder থেকে এসেছে

    $students=ModelName::get();
	$Exammark=ModelName::get();
	$totalData=$students->merge($Exammark);

Insert by Modelএটা Query Builder থেকে এসেছে

$result= ModelName::insert(['name'=>'josim','class'=>'5','roll'=>'4']);

Delete by Modelএটা Query Builder থেকে এসেছে

ModelName::delete();

** controller এর সাথে model কে যুকত করার জনে উপরে
use App\যে model কে যুকত করব তার নাম studentsModel;

Exm:: controller এর মধে 
{
	function allSelect(){
	$result= যে model কে যুকত করব তার নাম studentsModel::get();
	return $result;
}
}
get(); এটাই হছে expresion


class 82 Model use Retriving, Aggregates,Insert,Delete,Updates


class 83 Database:Seeding 
Seeding তৈরির কমানড
php artisan make:seeder nameofseeder

তৈরি করা সিডার থাকবে database>seeds এর মধে থাকবে

Seeding is a process to insert some dummy data in table

seed কে রান করার জনে terminal থেকে commend > composer dump-autoload তার পরে
php artisan db:seed --class= class এর নামটা যে class টা তৈরি করেছিলামstudentSeeder

Exm:: এটা controller এর সাথে কোন সমপক নাই
নতুন তৈরি করা সিডারে লিখব
public function run(){
	DB::table('student')->insert([
	'name' => Str::random(10),
	'email' => Str::random(10).'@gmail.com',
	'password' => Hash::make('password'),

	]);
}
'password' এই গুলাই আমার student table এ তৈরি করা কলামের নাম হবে এবং যতবার রান করব ততবার random লি টেবিলে ডাটা যুকত হবে



class 84 Database:Seeding

Work With Multiple Seeder Class

$this->call([
StudentSeeder::class,
ExammarKsSeeder::class

]);

যয়টা টেবিল আছে তইটা সিডার ফাইল তৈরি করে নিব

২ বা ততোধিক সিডার ফাইলকে একসাথে যুকত করার জনে আরও একটি সিডার ফাইল তৈরি করলাম এবং এখানেই $this->call([
StudentSeeder::class,
ExammarKsSeeder::class

]);এই কোড গুলো হবে StudentSeeder, ExammarKsSeeder এই গুল হছে  সিডার ফাইলের নাম যা একসাথে রান হবে
