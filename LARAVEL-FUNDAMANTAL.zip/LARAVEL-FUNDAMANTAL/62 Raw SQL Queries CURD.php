class 62 Laravel Raw SQL Querues
Basic CURD Operation
ধরি তৈরি করা টবিলের নাম student
C>>DB::insert('insert into student (id,name) values(?, ?)',[1,'josimuddin']);

U>> DB::update('update student set name = ? where id = ?', ['josim',1]);

R>> read korar jony>>$student = DB::select('select * from student where name = ?', ['josim']);

D>> DB::delete('delete from student where name = ?',['josim']);

1.একটি controller ও insert,select,delete,update view তৈরি করলাম
2. তার পরে route করে দিলাম

class 63 

1.আমরা DB নামে যে content নিয়ে কাজ করব তাকে আগে যে controller এ use করব তা উপরে যোগ করে দিব
2.use Illuminate\Support\Facades\DB; এটা যোগ করে দিতে হবে
3. তার পরে তৈরি করা controller এর মধে 
 function oneSelect(){
 $jsonData= DB::select('select * from student মানে টেবিলের নাম');
 $jsonString= json_encode($jsonData);
 $selectData= json_decode($jsonString);
 return view('select',['selectKey'=>$selectData]);
}

4.তার পরে viwe এর মধে data পাঠানোর জনে বা connect করার জনে

<table>
	@foreach($selectKey as $item)
	<tr>
		<td>{{$item->name মানে টেবিলের যে নাম থাকবে সেটাই হবে}}</td>
		<td>{{$item->class মানে টেবিলের যে নাম থাকবে সেটাই হবে}}</td>
		<td>{{$item->roll মানে টেবিলের যে নাম থাকবে সেটাই হবে}}</td>
	</tr>

@endforeach
</table>
5. তারপরে আউটপুট দেখানোর জনে তো route করতে হবে controller কে

************************************************************************
class 68 Laravel Query Builder

class 69 Retrieving Results Retrieving(রিটাভিং)

use Illuminate\Support\Facades\DB;এটা সকল controller এর মধে দিতে হবেDB class টা use করার জনে

এটা select এর মত database থেকে data গুলোকে আউটপুটে দেখানোর জনে

1.Retrieving All Rows From A table >> DB::table('table এর নাম student')->get();

2.Retrieving A Single Row >> DB::table('student')->where('name','=','josim')->first();

3.Column From A Table >> DB::table('user')->where('name','josim')->value('email');
যেখানে id=8 সেখানের name টা just চাছি
DB::table('user')->where('id','=','9')->value('name');

4. ow by its id column value,use the find method>> DB::table('users')->find(3);
5. Retrieving A List of column value>> DB::table('roles')->pluck('title');
6. Retrieving A List Of Column Values>> DB::table('rles')->pluck('title','name');

এবং controller এর মধে 
function selectAllRows(){
	$result= DB::table('student')->get();
	return json_encode($result);
	ডাটা গুলোকে string এ convert করার জনে json_encode use করা হয়
}
এই রকম ভাইবে হবে সবগুলো

class 70 Aggregates
1. Count Row Number >> $users=DB::table('student')->count();
2. Find Max value >> $price=DB::table('student')->max('কলামের নাম যার max value বের করব যেমন id');
3. Find Min value >> $price=DB::table('student')->min('কলামের নাম যার Min value বের করব যেমন id');
4. Find Average >> $price=DB::table('student')->avg('কলামের নাম যার avg value বের করব যেমন roll');

class 71 Select ও Retrieving পায় একই Retrieving মানে পনুধার করা Select নিবাচন করা
Retrieving করতে হলে json_decode করতে হয় আর এখানে হয় না

1. ইউনিক ডাটা select করে দেখানোর জনে >> DB::table('')->distinct()->get();
2. select single column >> DB::table('')->select('name');
3. select multipul column >> DB::table('')->select('','')->get();

function Uniqueselect(){
	$result = DB::table('student')->distinct()->get();
	return $result;
}

class 72 multiple table থেকে multiple data কে একসাথে যুকত করতে চাইলে marge নিয়ে কাজ করতে হবে

exm: controller এর মধে
function mergeData(){
	$students=DB::table('studentsটেবিলের নাম')->get();
	$Exammark=DB::table('exm টেবিলের নাম')->get();
	$totalData=$students->merge($Exammark);
	return $totalData;
}

class 73 Leftjoint

controller এর মধে
function LeftJoinData(){
	$result= DB::table('studesnt')
	->leftjoin('exam_marks', 'students.roll','=','exam_marks.roll')
	->get();
	return $result;
}

students.roll student টেবিলের roll কলামের সাথে exam_marks.roll টেবিলের rollকলাম joint হয়ে যাবে আর যে গুলা অমিল থাকবে তাই দেখাবে

class 74+ 75 Insert new row.

controller ar moddha
function insertRow(){
	$result= DB::table(table:'students')->insert(['name'=>'josim','class'=>'5','roll'=>'4']);

	if($result==true){
	return "Insert Success";
}else{
	return "Insert Fail";
}

}
name, class,roll এ গুলো কলামের নাম

class insert এর মতই একাধিক data insert করতে চাইলে
controller ar moddha
function insertRow(){
	$result= DB::table(table:'students')->insert(
	[
	['name'=>'josim','class'=>'5','roll'=>'4'],
	['name'=>'josim2','class'=>'52','roll'=>'42'],
	['name'=>'josim3','class'=>'523','roll'=>'423'],

	]

	);

	if($result==true){
	return "Insert Success";
}else{
	return "Insert Fail";
}

}

insert এ duplicate value দিলে error আসে এবং program run করতে দেই না
আর insertOrIgnore দিলে program run হয়

class 76 Delete

1. Delete on row>> DB::table('students')->where('name','=','josim')->delete();
2. Delete all row but not reset autoincrement id>> DB::table('students')->delete();
3. Delete all row and reset autoincrement id>> DB::table('students')->truncate();

Exm: controller create করে controller এ কোড
function oneDelete(){
	$result= DB::table('students')->where('name','=','josim')->delete();

	if($result==true){
	return "Delete Success";
}else{
	return "Delete Fail";
}
}
name হছে কলামের নাম আর josim হছে কলামের মধে থাকা ডাটা যেটা delete হবে।
টেবিল টে হবে name class roll নিয়ে

class 77 Update

DB::table('students')->where('id',1)->update(['name'=>'new name']);
exm: controller তৈরি করে controller এর মধে
function onUpdate(){
	$result= DB::table('students')->where('name','=','josim')
	->update(['name'=>'josim Uddin','class'=>'one','roll'=>'one']);
	if($result==true){
	return "Update Success";
}else{
	return "Update fail";
}
}
name হছে কলাম আর josim হছে কলামের মধে থাকা value

Controller এ

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\studentsTableModel;যে মডেল নিয়ে কাজ করছি তার নাম

class studentTableController extends Controller
{
   function selectData(){
       $result = studentsTableModel::get();
       return $result;
   }

   function SingleData(){
    $result = studentsTableModel::where('Name','=','GZfBV')->first();
    return $result;
}


function InsertData(){
	$result = studentsTableModel::insert(['Name'=>'josim Uddin','Email'=>'josim@gmail.com','Password'=>'josim123456789@']);

	if($result==true){
	return "Insert Success";
}else{
	return "Insert Fail";
}

}

function DataDelete(){
    $result = studentsTableModel::where('Name','=','josim Uddin')->delete();
    if($result==true){
        return "Delete Success";
    }else{
        return "Delete Fail";
    }
}


function Update(){
    $result= studentsTableModel::where('Name','=','GZfBV')
	->update(['Name'=>'josim Uddin','Email'=>'josim123@gmail.com','Password'=>'Afrin123']);
	if($result==true){
	return "Update Success";
}else{
	return "Update fail";
}
}

}


Route এ

Route::get('/select','studentTableController@selectData');
Route::get('/single','studentTableController@SingleData');
Route::get('/insert','studentTableController@InsertData');
Route::get('/delete','studentTableController@DataDelete');
Route::get('/update','studentTableController@Update');