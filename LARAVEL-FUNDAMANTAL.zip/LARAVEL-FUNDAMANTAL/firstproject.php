class 39
1.Resources এর মধে sass,js এবং view folder এর মধে যা আছে delete করে bootstrap নিয়ে কাজ করার জন যা লাগে setup করব
2.view এর মধে folder করব layout নামে যার মধে app.blade.php নামে ফাইল থাকবে যেখান থেকেই html,css,js other পেজে পাবে
3. view এর মধে home,about,portfilio,contact.blade.php flie create করব

class 40
view তে যে পেজ তৈরি করেছি তা controller এর সাথে যুকত করে controller কে route করে output দেখানো

class 41
resources>view>layout>app.blade.php আছে বা তৈরি করেছি সেখানে basic html,link css,link js সকল কিছু থাকবে
2. view এর মধে যে css,js,lang,sass,images floder গুলো তৈরি করেছিলাম বা আছে সেগুলোকে cut করে public folder এর মধে past করে দিলাম কারন laravel এর asset এর মাধমে এগুলোকে conect করব তাই
3.link করা 
asset হছে laravel এর মেথড এটা দেওয়ায় লাগবে
syntex:
<link rel="stylesheet" type="text/css" href="{{asset('folderName/fileName')}}"> 
exm:
<link rel="stylesheet" type="text/css" href="{{asset('css/bootstrap.min.css')}}">
4. layout>menu,footer.blade.phpআছে তাকে app.blade.php এর মধে যে basick html,body,js আছে তার 
<body>
	@include('foldername.filename')
	@include('layout.menu')

other page এ style দেওয়ার জনে 
@yield('content')দিতে হবে 


	@include('foldername.filename')
	@include('layout.footer')

</body>

class 42
1. MasterLayout page কে সকল পেজের সাথে add করতে হবে নইলে other পেজ গুলো style পাবেনা
syntex:
@extends('folder.file')
exm:
@extends('layout.app')

2. title গুলো ডাইনামকলি পাঠারোর জনে @section('title','যে পেজ দেখাব তার নাম')
@section('title','Home') এটা home.blade.php তে
@section('title','About') এটা About.blade.php তে
আর app.blade.php তে <title>@yield('title')</title>হবে

class 43
1. bootstrap থেকে nav bar নিয়ে এসে menu.blde.php তে রাখা
2. menu এর url কে route এর সাথে যকত করা 
<a href="{{url('/route এর নাম আর না দিলে Home পেজেই থাকবে')}}"></a>Home
<a href="{{url('/about')}}"></a>

class 44 
1. Footer create করা footer.blade.php তে footer তৈরি করা যা layout এর মধে আছে

class 45 about page a content দিলাম
class 46 portfolio page a card তৈরি করে দিলাম
class 47 service page a Bootstrap এর form  তৈরি করে দিলাম
class 48 Home page   তৈরি করে দিলাম
.parallax{
	background-image:url("../images/banner.jpg");
	min-height:500px;
	background-attachment:fixed;
	background-position:center;
	background-repeat:no-repeat;
	background-size:cover;

}

