class 51 Laravel Migration মানেই Data Base Manage নতুন ডাটা টেবিল create করা
1. Laravel Migration allows you to create a table i  your database.
2. you can modify the table by adding a new column or deleting an existing column.

Migration ::
1. Create a MySQL database.
2. Connect with laravel.

Data Base connect করার জনে laravel এর .env এর মধে গিয়ে নতুন তৈরি করা ডাটাবেসের নাম টা just দিতে হবে আর বাকি সব ঠিক থাকবে

class 52 Create New Migration
1. php artisan make:migration MigrationFileName

database এর মধে migration এর মধে Up Method ও Down Method ২টা function আছে
Up Method
1. works only at front Migration
2.can Create Table, Column,Index ect
3.Can Modify Table, Column,Index
4.Can Delete Table,Column,Index ect

Down Method এর মধে পাথক হছে এটা
 just works only for migration roll back এটা ছাড়া বাকি সব ঠিক 

 class 53 First Migration Table Create

 public function up(){
 Schema::create('যে নামে তৈরি করব তার নাম students',function(Blueprint $table){
$table->bigIncrements('id');
$table->string('name');
$table->string('roll');
$table->string('class');
$table->timestamps();

});
}
তার পরে commend  chalate hobe 
cd josim>
php artisan migrate


class 54 Migration column Creation Method

1.**** $table->bigIncrements('id') কাজ primary key auto-incrementing
2.***** $table->bigInteger('Vote') কাজ large number ar integer সংখা নিয়ে কাজ করার জনে
3. $table->binary('data') কাজ binary large object  নিয়ে কাজ করার জনে
4.***** $table->boolean('confirmed') কাজ boolean true or false  নিয়ে কাজ করার জনে
5. $table->char('name',100 মানে ১০০টা পযনত হবে) কাজ charectar কারেকটার  নিয়ে কাজ করার জনে
6.****  $table->date('Created_at') কাজ date   নিয়ে কাজ করার জনে 
Created_atএখানে যে নাম দিব সেই নামে data store হবে
7. $table->dateTime('Created_at') কাজ dateTime   নিয়ে কাজ করার জনে Created_atএখানে যে নাম দিব সেই নামে data store হবে
8. $table->dateTimeTz('Created_at') কাজ dateTimeTz সাথে টাইম জোন অনুযায়ী data store হবে
11. $table->ipAddress('visite') কাজ ipAddress  অনুযায়ী data store করতে চাইলে
12. $table->json('option') কাজ json  অনুযায়ী data store করতে চাইলে
13.**** $table->longText('description') কাজ longText অনেক বড় description store করতে চাইলে
14. $table->macAddress('device') কাজ macAddress  অনুযায়ী data store করতে চাইলে
15. $table->mediumInteger('votes') কাজ mediumInteger  অনুযায়ী data store করতে চাইলে
16. $table->mediumText('description') কাজ mediumText  অনুযায়ী data store করতে চাইলে
17. $table->smallinteger('votes') কাজ smallinteger  অনুযায়ী data store করতে চাইলে
18. $table->smallincrements('id') কাজ smallincrements  অনুযায়ী data store করতে চাইলে
19. *** $table->string('name',100) কাজ string  অনুযায়ী data store করতে চাইলে
20. **** $table->text('description') কাজ text  অনুযায়ী data store করতে চাইলে
21. ***** $table->time('sunrise') কাজ time  অনুযায়ী data store করতে চাইলে
22. $table->timestamps('sunrise') timestamps created o updatet সময় এর জন কলাম তৈরি হবে
23. $table->year('birth_year') শুধু মাত year রাখতে চাইলে 

class 55 important Blueprint value
1. $table->bigIncrements('id'); Auto Id generate হবে 
2. $table->bigInteger('votes'); Integer value নিয়ে কাজ করে data base
3. $table->binary('img'); বাইনারি আকারে ছবি পাঠানো
4. $table->boolean('confirmed'); true false data store করে
5. $table->char('name',50);
6. $table->dateTimeTz('Created_at');
7. $table->ipAddress('visitor');
8. $table->longText('description');
9. $table->string('city',1000);

 তার পরে commend  chalate hobe 
cd josim>
php artisan migrate


class 56 Migration Modifying
1.firstly 
******* composer require doctrine/dbal এই কমানড চালালে Error দেখাবে তাই
 নিচের কমানড দিয়ে composer require করতে হবে
  composer require doctrine/dbal:^2.12.1

.নতুন migration তৈরি করতে হবে কোন migration কে change করার জনে এবং তার up function এর মধে (schema::table) এটা হবেই

টেবিলের সাইজ chenge করা

1. schema::table('যে টেবিলকে size change করব তার নাম',function(Blueprint $table){
	$table->string('name',1000)->change(); এর মান যায় থাকুক না কেন এর পরে হয়ে যাবে  ১০০০ .তার পরে কমানড দিয়ে রান করতে হবে.
});

class 57 

1. schema::table('যে টেবিলকে rename করব তার নাম',function(Blueprint $table){
	$table->renameColumn('form','to'); মানে $table->renameColumn('যেটা আছে','যা হবে');

2.schema::table('যে টেবিলকে Delete করব তার নাম',function(Blueprint $table){
	$table->dropColumn('যে কলাম ডিলিট করব তার নাম'); or
	$table->dropColumn(['যে যে কলাম ডিলিট করব তার নাম','যে যে কলাম ডিলিট করব তার নাম']);

class 58 Table Modyfication
1. Schema::rename('from', 'to'); >> Table Rename;
2. schema::drop('এখানে টেবিলের নাম'); >> table delete;
3. schema::dropIfExists('এখানে টেবিলের নাম'); >> table delete if exists


class 59 Migration History And Batch value 
Batch value মানে বার কত তম বারে করা হয়েছে


class 60 Migration Rolling Back

1. php artisan migrate:rollback  >> roll back the last "batch" of migrations
2. php artisan migrate:rollback --step=2 >> rollback the last 2 migrations 2এ জায়গাতে  যত value দিব last থেকে ততো Delete হয়ে যাবে
3. php artisan migrate:reset >> roll back all of your application's migrations

4. php artisan migrate:refresh >> roll back all of your migrations and then execute the migrate command

5. php artisan migrate:refresh --step=3 >> rollback & re-migrate the last 3 migrations.
******** just উপরের commande গুলো রান করালেই কাজ করবে


class 61 Rolling Back Migration With Down Method()
মানে যখন roll back করব তখন roll back অনুযায়ী এটা টেবিল তৈরি বা আদার কাজ গুলো করবে এটার মেন হছে এর কোন কমানড নাই roll back ই তার কমানড

1. যখন কোন igration কে roll back বা ডিলিট করা হবে তখনি down মেথড কাজ করবে
public function down(){
	এখানে কোড up মেথডের মতাই হবে;
	migration Delete বা roll back হওয়ার সাথে সাথে নতুন টেবিল টা down এর মাধমে তৈরি হয়ে যাবে.
}