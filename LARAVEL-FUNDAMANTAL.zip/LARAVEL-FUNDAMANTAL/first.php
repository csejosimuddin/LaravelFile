


Laravel নিয়ে কাজ করার জন্য এই তিনটা টুলস লাগবে
1.Xampp
2. Composer হচ্ছে PHP এর প্যাকেজ ম্যানেজার
3. Visual Studio Code
http://127.0.0.1:8000
 Install
4. https://laravel.com/docs/8.x এর ডকুমেন্ট দেখে visual stdio থেকে terminal থেকে comand dibo

5. MVC:Software কে তিনভাগে ভাগ করে  Develop করা , বা source code সাজানো

. model       : Data Structure
. View        : The Visible part of Application
. Controller  : Logics Of Application


	Class 06	Essential PHP Artisan Command এই কমানড গুলো কাজে লাগে


   Command                   ACTION
php artisan serve   > To run laravel application
php artisan make:Controller ControllerName > To make new Coltroller
php artisan make:Model ModelName > To make new Model
php artisan make:Middleware MiddlewareName > To make new Middleware
php artisan make:migration migrationName > To make migration file
php artisan migrate > To run migration

=============================================================
php artisan cache:clear >clear application cache
php artisan route:clear >clear route cache
php artisan config:clear >clear config cache
php artisan view:clear >clear compiled view files


class 07		Basic Routing

url সেটিং এর বিষয়টাই হছে Routing বা রাউট করা
url set kora
routes>web.php আছে  
নতুন রাউট তৈরি করলাম
Route::get('/josim', function () {
    return "Programmer Josim";
});


. Routing is a process to set url, that requested by browser
. the route/web.php directory contains the definition of route files

	class 08  view এর সাথে রাউট কে যুকত করা

1. resources এর মধে view এর মধে view file তৈরি করলাম Homepage.blade.php
2.Routes এর মধে routing করলাম

Route::get('/',function(){
return view('Homepage');

});

 class 09 routing with controller

 1. first create controller
  php artisan make:Controller ControllerName.
 2. Then route with Controller name and method.

 Controller এর মধে যে মেথড আছে তাকে রাউট করাব তাই Controller তৈরি করলাম
 route এর মধে web.php তে Route::get('/', 'App\Http\Controllers\SiteController@Home'); laravel 8x verson a
 Route::get('/', 'SiteController@Home'); laravel 7 verson a
 SiteController Controllerএর নাম Home এটা মেথড যাকে হোমে দেখাব
 Route::get('/about', 'App\Http\Controllers\SiteController@About');


class 10 Routing with Controller And View

1. View কে Controller এর সাথে যুকত করা আর controller কে রাউট করা 
function Home(){
	return view('HomePage');
}
View এর মধে HomePage.blade.php আছে সেখান থেকে HomePage এটা নেওয়া 
আর রাউট তো এভাবে করতে হবে Route::get('/', 'App\Http\Controllers\SiteController@Home'); Laravel 8X এ


class 11  Routing with href link
Normal: <a href="www.google.com">Home</a>

Laravel Route: <a href="{{url('এখানে কোড হবে route এর কোড দেখে')}}"></a>
<a href="{{url('/')}}">Home</a>
<a href="{{url('about')}}">About</a>


class 12 Routing Parameter

1. Route a set করা parameter কে controller এ ধরে নিয়ে যাব 
url parameter এর মধে value পাস করা
Route::set('/home/{namevalue}', 'SiteController@Home');
SiteController তৈরি করা controller এর নাম
class DemoController extends Controller
{
   function myName($namevalue){
        return $namevalue;
   }
}

class 13 একাধিক parameter pass kora
 Url এর মধে multiple parameter Controller এর মধে পাস করা

Controller এর মধে

function myName($firstname, $middlename, $lastname){
     return "First Name:". $firstname."<br> Middle Name:". $middlename. "<br>Last Name:". $lastname;
   }

   Route এর মধে

Route::get('/Name/{firstname}/{middlename}/{lastname}', 'DemoController@myName');


class 14 Routing parameter
Route>Controller>View
Controller ar data k view এর মধে পাস করা

Controller এর value কে view এ পাস করার জনে 

1.class DemoController extends Controller
{
   function myName($firstname, $middlename, $lastname){
     return view('Demoview',['firstkey'=>$firstname, 'middlekey'=>$middlename, 'lastkey'=>$lastname]);
   }
}

এটা ['firstkey'=>$firstname, 'middlekey'=>$middlename, 'lastkey'=>$lastname] associtive array

2. Route::get('/Name/{firstname}/{middlename}/{lastname}', 'DemoController@myName');
3.<h1>First Name: {{$firstkey}}</h1>
<h1>Middle Name: {{$middlekey}}</h1>
<h1>Last Name: {{$lastkey}}</h1>


class 15 Routing Group


Route::group(['prefix'='যা দিব তাই'>],callbackfunction);
1. Grouping multiple route we can provide common features to all
2. Using route group you can use common path prefix
3. Using route group you can use common middleware
Exam web.php তে

Route::group(['prefix'=>'account'], function(){

    Route::get('/profile', function(){
        return "This is Profile";
        });
        
        Route::get('/Login', function(){
            return "This is Login";
            });
        
            Route::get('/Logout', function(){
                return "This is Logout";
                });
        
                Route::get('/Profileupdate', function(){
                    return "This is Profileupdate";
                    });

});


class 16  Laravel controller এর আগে যা শিখেছি
. controller view এ রিটান করে
. controller থেকে view তে ডাটা pass করানো যায়
. controller এর মধে route parameter এর মাধ্মে data নেওয়া যায়

 এখন যা শিখব
 . controller এর মধে লজিক লেখা যায়
 . controller এর মধে model use করে database থেকে select,Delete,Insert,Update করা যায়
 . controller এর মধে Middleware Use করা যায়
 . controller থেকে JSON  Response দেওয়া যায়
 . controller এর মধে JSON Request রিসিভ করা যায়

 class 17 controller structure just Controller কি ভারে তৈরি করতে হয় দেখালছে

 দাদা base controller>>বাবাcontroller>>আপনি Those we create

 class 18 Types of Laravel Controller
 . Custom Controller যেটা আপনি নিজের মত করে করেছেন
 . Single Action  Controller যেটি একটি মাতর কাজ করে
 . Resource Controller যেটি সব  ধরনের Http Request Handle করে CURD Operation করতে পারে
 .Middleware Controller যেটি  Request এবং Response এর মধে use কার হয়


class 19 Single Action Controller

. Single Action  Controller যেটি একটি মাতর কাজ করে
syntex:
class Controller এর নাম হবে extends Controller{
	public function __invoke(){

}
}
public function __invoke() এটা দিতেই হবে যা আছে তাই 
. Single controller কে রাউট করার সময় just Controller এর নাম দিলেই হবে @ দিয়ে মেথডের নাম দেওয়া লাগবে না
Route::get('/','myController');

class 20 Resource Controller

Resource Controller তৈরির কমানড 
php artisan make:Controller photoController --resource

Resource Controller Route তৈরি করতে ওভাবে
Route::resource('photos','photocontroller');
photo  পাথ নাম,photocontroller controller এর নাম

index,create,show,edit এগুলা GET
store > POST
update> PUT/PATCH
destroy> DELETE

output দেখার link:
index>> /photos
create>> /photos/create
show>> /photos/135 id এটা 
edit>> /photos/1475/edit

class 21 Custom Controller

class 22 Laravel Views
.blade.php তে কি কি ফিচার আছে বা শিখব
. Template Inheritance
. Components & Slots
. Displaying Data
. Blade & JavaScript Frameworks
.Control Structures
. Forms
. Including Sub-Views
. Service Injection
. Extending Blade


class 23 Simple Blade View 

1. Blade View তৈরি করব
2. controller এর সাথে যোগ করব 
3. Route করব


class 24 pass & Display Data inside blade view

$jamai= "valo jamai";
controller এর মধে variable নিলে তাকে view এর মধে পাস করার জনে associtave array নিয়ে কাজ করতে হয় return view('name',['abul'=>$jamai]);
. আর view তে {{ $abul }} or {!! $abul !!} হবে
. {{ $abul }} এটি যায় দিন না কেন সবকে strignরে দেই


class 25 For Loop inside blade view

syntex:
@for($i=0; $i<100; $i++)
<button>{{$i}}</button>এটা দিলে নামবার সহ দেখাবে or নিচের টা দিব
<button>Button</button>
@endfor
যায় লুপের মধে দিব তাই দেখাবে

class 26 Foreach Loop inside blde view
syntex:
@foreach($Data as $Name)
{{$Name}}
@endforeach  

exm: value গুলোকে dropdown আকারে দেখার জন একাধিক value নিয়ে কাজ করার জন array নিয়ে কাজ করারা জনে
view.php
<select name="" id="">
@foreach($country as $value)
<option value="">{{$value}}</option>
@endforeach
</select>

controller.php
function Myhome(){
    $country = array("Bangladesh","India","America","Canada");
      return view('Home',['country'=>$country]);
  }


  class 27 Forelse Loop foreach এর মতই but array ফাকা থাকলে কি হবে তার জনে forelse
  syntex:
  @forelse($Data as $Name)

  {{$Name}}
  @empty
  <p>No Data</p>
  @endforelse


  calss 28 if else condition

  @if()

  @elseif()
  @else()
  @endif

  class 29 Loops Special properties download option aca

  link : https://laravel.com/docs/7.x/blade#the-loop-variable

  class 30 php inside blade view
  @php
  echo "Hello"
  @endphp


class 31 Including Subview Blade view
1. Simple Including Subview
2. Passing Data to Subview
3. Advance including

subview হছে একটি application বা website এর এক একটি part আর অনেক গুল subview মিরে তৈর হয় মেন view 

@include('subview.menu')মানে view এর মধে subview আছে আর subview এর মধে menu file টা আছে

class 32 passing data to subview 

Data pass করার সময় key tha variable হয়ে যাবে
['copyright'=>'All right josim'])ডাটা দিলাম
{{$copyright}}আউটপুট

class 33 Advance including 
@includeif(['subview.hader','subview.footer']) মানে একাধিক subview কে একসাথে লিখা যায়
@includeif('subview.header')এটা করলে ভুল হলেও error দেখাবেনা
@includefirst(['subview.hader','subview.footer']) এখানে just subview.headerএর ভিউ টা কেই দেখাবে

class 34 

. @includeWhen($boolean,'view.name'['some'=>'data'])এখানে boolean value true হলে output দেখাবে আর না হলে দেখাবে না

. @includeUnless($boolean,'view.name'['some'=>'data'])এখানে boolean value false হলে output দেখাবে আর না হলে দেখাবে না

exam: @includeWhen(true,'subview.header')তাহলে দেখাবে fales হলে দেখাবে না
exam: @includeUnless(true,'subview.header')তাহলে দেখাবে fales হলে দেখাবে না

class 35 Blade Template Inheritance | master Layout Concept
1. master Layout এ সকল কমন ফাইল থাকে html css java etc

class 36 connect masterlayout

১. create master layout>> Resources>newfolder korte hobe >layout>than এর মধে ফাইল তৈরি করব যে কোন নামে MasterLayoutনামে করলাম তার পরে এখানে Bootstrap এর টোটাল ফাইল দিব html,css,java যা লাগে

২.Homepage বা যাদের সাথে এই ফাইল connect করব সেখানে @extends('flodername.filename')যেমন @extends('layout.MasterLayout')


class 37 
@yield() ও @section() এই ২টা একসাথে মিলে কাজ করে একাই পার না

সাধারণ পেজ থেকে ডাটা যখন masterLayout এ পাঠাব তখন এটি কাজে লাগবে
সাধারণ পেজ থেকে ডাটা পাঠানোর সময় @section('titleKey','Home Page')
masterLayout এ ডাটা রিসিভ করে দেখানোর জনে @yield('titleKey')

class 38 
. MasterLayout page ar css, js পাইতে হবে সবকেই বা সকল পেজকে বা যে যে পেজ সুবিধা ভোগ করবে তাদের কে @section('এখানে একটি নাম')এখানে পেজের সকল ডাটা তারপরে@endsection
.আর MasterLayout পেজে body এর মধে @yield('section এর খানে একটি নাম হবে')