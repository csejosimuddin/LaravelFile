class 85 Http Client
REST API কে USE করার জনে হছে Http Client 

1.এটি হছে একটি process যার মাধমে 3rd parti কোন সাভারে server এ বা কোন url এ request পাঠানো যায় এবং সেই request অনুযায়ী যে রেসপনস আসে তা রিসিভ করা যায়

2.get,put,post,delete,header ,body বিভিন ভাবে request পাঠাতে পারি আমরা
3. REST API কে কনজুম করার জনে এটি বেশি use করা হয় apishooter.com
4. যেমন ধরুন মোবাইলের bulk SMS integreate করতে চাইলে তার API কে কল করতে হবে তখন আমরা তা Http Client এর মাধমে কল করব
5. পুশ নোটিফিকেশনের জন যখন API use করতে হবে তখন ও Http Client এর মাধমে করতে হবে
6. 3rd পাটি ফিচার বা এলিমেনট গুলো কে use করার জনে Http Client use করতে হবে


class 86 Http Client

get ও post method বেশি কাজে লাগে

Http Client নিয়ে কাজ করতে হলে first a add করে দিতে হবে

use illuminate\Support\Facades\Http;

1. controller এর মধে উপরে যোগ করতে হবে
use Illuminate\Support\Facades\Http;
এর জনে Laravel lumen API  এর part টা দেখতে হবে আগে

*********** Simple get request

use Illuminate\Support\Facades\Http;

$response = Http::get( url:"" );
$response->body();
$response->json();
$response->status();
$response->ok();
$response->successful();
$response->serverError();
$response->clientError();
$response->header( header:"Key" );
$response->headers();

একটি controller তৈরি করব তার পরে এবং use Illuminate\Support\Facades\Http; যুকত করতে হবে
controllerএর মধে 

Exm: function simpleGetHttprequest(){
	$response= Http::get("http://apishooter.com/getSimpleString");
	return $response->body();এই Response টা উপর থেকে আসছে এখানে $response->API অনুযায়ী যা দিব তাই আউটপুটে দেখাবে
}তারপরে আউটপুট দেখানোর জন Route করে দিব

class 87

****  Simple Post
1. use Illuminate\Support\Facades\Http;
2. $response = Http::post(url:'',['Key'=>'data']);
Exm:Controller এর মধে
function simplepostHttprequest(){
        $response = Http::post("http://apishooter.com/postSimpleString", ['text'=>'Damy Data']);
        return $response->body();
    }


    class 88 JSON Get Request
    Exm01: function jsonGetHttpRequest(){
    $respons = Http::get('http://apishooter.com/getArticleList');
    return $respons->json(); এর মানে ডাটা গুলো JSON আকারে আসবে
}


class 89
function personAdd(){
	$response = Http::post('http://apishooter.com/addPerson',['name'=>'josim','age'=>'josim','city'=>'josim','mobile'=>'01516166907']);
	return $response->body();
}

Exm02:
function Deleteperson(){
	$response = Http::post('http://apishooter.com/deletePersonById',['id'=>'8']);
	return $response->json();
}

Exm03:
function personbyid(){
	$response = Http::post('http://apishooter.com/deletePersonById',['id'=>'1']);
	return $response->body();
}

মোট কথা 3rd party API নিয়ে কাজ করতে চাইলে Http Client দিয়ে Request পাঠাতে হয় 
এটাই হছে Http Client এর কাজ 